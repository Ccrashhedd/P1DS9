package com.example.proyecto1.network

import com.example.proyecto1.model.*
import retrofit2.Call
import retrofit2.http.*

interface ApiService {
    @GET("get_productos.php")
    fun getCatalogo(): Call<List<Producto>>

    @POST("login_empleado.php")
    fun login(@Body request: LoginRequest): Call<LoginResponse>

    @POST("procesar_factura.php")
    fun procesarPago(@Body request: PagoRequest): Call<BaseResponse>

    @GET("buscar_producto.php")
    fun buscarProducto(@Query("idProducto") id: Long): Call<ProductoResponse>

    @POST("guardar_producto.php")
    fun guardarProducto(@Body producto: Producto): Call<BaseResponse>
}
