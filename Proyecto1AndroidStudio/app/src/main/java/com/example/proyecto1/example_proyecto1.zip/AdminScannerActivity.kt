package com.example.proyecto1

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.proyecto1.model.BaseResponse
import com.example.proyecto1.model.Producto
import com.example.proyecto1.model.ProductoResponse
import com.example.proyecto1.network.RetrofitClient
import com.example.proyecto1.scanner.CameraPreview
import com.example.proyecto1.ui.theme.Proyecto1Theme
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class AdminScannerActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            Proyecto1Theme {
                var scannResult by remember { mutableStateOf<String?>(null) }
                var showForm by remember { mutableStateOf(false) }
                var selectedProducto by remember { mutableStateOf<Producto?>(null) }
                var isScanning by remember { mutableStateOf(true) }

                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Panel de Administrador", style = MaterialTheme.typography.headlineMedium)
                    Spacer(modifier = Modifier.height(16.dp))
                    
                    if (isScanning) {
                        Box(modifier = Modifier.height(300.dp).fillMaxWidth()) {
                            CameraPreview { code ->
                                isScanning = false
                                scannResult = code
                                analizarCodigo(code) { producto ->
                                    selectedProducto = producto
                                    showForm = true
                                }
                            }
                        }
                    }

                    if (showForm) {
                        ProductForm(
                            producto = selectedProducto,
                            codigoDefault = scannResult ?: "",
                            onSaved = { 
                                showForm = false
                                selectedProducto = null
                                isScanning = true
                            },
                            onCancel = {
                                showForm = false
                                selectedProducto = null
                                isScanning = true
                            }
                        )
                    }
                }
            }
        }
    }

    private fun analizarCodigo(codigo: String, onResult: (Producto?) -> Unit) {
        val id = codigo.toLongOrNull() ?: 0L
        RetrofitClient.instance.buscarProducto(id).enqueue(object : Callback<ProductoResponse> {
            override fun onResponse(call: Call<ProductoResponse>, response: Response<ProductoResponse>) {
                if (response.isSuccessful && response.body()?.ok == true) {
                    onResult(response.body()?.datos)
                } else {
                    onResult(null) // Producto nuevo
                }
            }
            override fun onFailure(call: Call<ProductoResponse>, t: Throwable) {
                Toast.makeText(this@AdminScannerActivity, "Error de red", Toast.LENGTH_SHORT).show()
                onResult(null)
            }
        })
    }
}

@Composable
fun ProductForm(
    producto: Producto?, 
    codigoDefault: String, 
    onSaved: () -> Unit,
    onCancel: () -> Unit
) {
    var nombre by remember { mutableStateOf(producto?.nombre ?: "") }
    var precio by remember { mutableStateOf(producto?.precioVenta?.toString() ?: "") }
    var stock by remember { mutableStateOf(producto?.stock?.toString() ?: "") }
    val context = androidx.compose.ui.platform.LocalContext.current

    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(if (producto == null) "Registrar Nuevo Producto" else "Editar Producto", style = MaterialTheme.typography.titleMedium)
        Text("Código: $codigoDefault", style = MaterialTheme.typography.bodySmall)
        
        OutlinedTextField(value = nombre, onValueChange = { nombre = it }, label = { Text("Nombre") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = precio, onValueChange = { precio = it }, label = { Text("Precio") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = stock, onValueChange = { stock = it }, label = { Text("Stock") }, modifier = Modifier.fillMaxWidth())
        
        Button(
            modifier = Modifier.fillMaxWidth(),
            onClick = {
                val p = Producto(
                    idProducto = producto?.idProducto ?: (codigoDefault.toLongOrNull() ?: 0L),
                    nombre = nombre,
                    unidad = producto?.unidad ?: "Unidad",
                    descripcion = producto?.descripcion ?: "",
                    stock = stock.toIntOrNull() ?: 0,
                    precioCosto = producto?.precioCosto ?: 0.0,
                    precioVenta = precio.toDoubleOrNull() ?: 0.0,
                    imagen = producto?.imagen,
                    idCategoria = producto?.idCategoria ?: 1,
                    idMarca = producto?.idMarca ?: 1
                )
                
                RetrofitClient.instance.guardarProducto(p).enqueue(object : Callback<BaseResponse> {
                    override fun onResponse(call: Call<BaseResponse>, response: Response<BaseResponse>) {
                        if (response.isSuccessful && response.body()?.ok == true) {
                            Toast.makeText(context, "Guardado exitosamente", Toast.LENGTH_SHORT).show()
                            onSaved()
                        } else {
                            Toast.makeText(context, "Error al guardar", Toast.LENGTH_SHORT).show()
                        }
                    }
                    override fun onFailure(call: Call<BaseResponse>, t: Throwable) {
                        Toast.makeText(context, "Error de red", Toast.LENGTH_SHORT).show()
                    }
                })
            }
        ) {
            Text("Guardar")
        }
        
        TextButton(onClick = onCancel, modifier = Modifier.fillMaxWidth()) {
            Text("Cancelar")
        }
    }
}
