package com.example.proyecto1

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.proyecto1.model.*
import com.example.proyecto1.network.RetrofitClient
import com.example.proyecto1.ui.theme.Proyecto1Theme
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            Proyecto1Theme {
                MainScreen()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen() {
    val context = LocalContext.current
    var productos by remember { mutableStateOf<List<Producto>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }
    var carritoCount by remember { mutableStateOf(0) }

    // COLOR AZUL DE LA WEB
    val azulWeb = Color(0xFF2563EB)

    // LLAMADA AL MICROSERVICIO PHP
    LaunchedEffect(Unit) {
        RetrofitClient.instance.getCatalogo().enqueue(object : Callback<List<Producto>> {
            override fun onResponse(call: Call<List<Producto>>, response: Response<List<Producto>>) {
                if (response.isSuccessful) {
                    productos = response.body() ?: emptyList()
                }
                isLoading = false
            }
            override fun onFailure(call: Call<List<Producto>>, t: Throwable) {
                isLoading = false
                Toast.makeText(context, "Error conectando a XAMPP", Toast.LENGTH_SHORT).show()
            }
        })
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("DS9 Store", color = Color.White, fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = azulWeb),
                actions = {
                    BadgedBox(badge = { if(carritoCount > 0) Badge { Text("$carritoCount") } }) {
                        IconButton(onClick = { /* Abrir Carrito */ }) {
                            Icon(Icons.Default.ShoppingCart, "Carrito", tint = Color.White)
                        }
                    }
                    IconButton(onClick = {
                        context.startActivity(Intent(context, LoginActivity::class.java))
                    }) {
                        Icon(Icons.Default.Person, "Login", tint = Color.White)
                    }
                }
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(Color(0xFFF1F5F9)) // Fondo gris suave de la web
        ) {
            if (isLoading) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = azulWeb)
                }
            } else {
                Text(
                    "Catálogo de Productos",
                    modifier = Modifier.padding(16.dp),
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold
                )

                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    contentPadding = PaddingValues(8.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(productos) { producto ->
                        ProductoCard(producto) {
                            carritoCount++
                            Toast.makeText(context, "Agregado: ${producto.nombre}", Toast.LENGTH_SHORT).show()
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ProductoCard(producto: Producto, onAdd: () -> Unit) {
    Card(
        modifier = Modifier.padding(8.dp).fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(4.dp)
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(8.dp)) {
            // URL DE IMAGEN (Apunta a tu carpeta de imágenes en XAMPP)
            val imageUrl = "http://10.0.2.2/DS92026/P1DS9/APP/img/${producto.imagen}"

            AsyncImage(
                model = imageUrl,
                contentDescription = null,
                modifier = Modifier.height(100.dp).fillMaxWidth(),
                contentScale = ContentScale.Fit
            )

            Text(producto.nombre, maxLines = 1, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Text("$${producto.precioVenta}", color = Color(0xFF2563EB), fontWeight = FontWeight.ExtraBold)
            Text("Stock: ${producto.stock}", fontSize = 10.sp, color = Color.Gray)

            Button(
                onClick = onAdd,
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2563EB)),
                contentPadding = PaddingValues(0.dp)
            ) {
                Text("Comprar", fontSize = 12.sp)
            }
        }
    }
}