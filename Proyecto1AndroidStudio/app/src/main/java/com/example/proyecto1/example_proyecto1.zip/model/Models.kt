package com.example.proyecto1.model

import com.google.gson.annotations.SerializedName

data class Producto(
    val idProducto: Long,
    val nombre: String,
    val unidad: String,
    val descripcion: String,
    val stock: Int,
    val precioCosto: Double,
    val precioVenta: Double,
    val imagen: String?,
    val idCategoria: Int,
    val idMarca: Int
)

data class Empleado(
    val usuario: String,
    val nombre: String,
    val apellido: String,
    val rol: Int,
    val contrasena: String
)

data class LoginRequest(
    val usuario: String,
    val contrasena: String
)

data class LoginResponse(
    val ok: Boolean,
    val mensaje: String,
    val empleado: Empleado? = null
)

data class PagoRequest(
    val digitosTarjeta: String,
    val items: List<ItemCarrito>,
    val subtotal: Double,
    val itbms: Double,
    val total: Double
)

data class ItemCarrito(
    val idProducto: Long,
    val cantidad: Int,
    val precioUnitario: Double
)

data class BaseResponse(
    val ok: Boolean,
    val mensaje: String
)

data class ProductoResponse(
    val ok: Boolean,
    val datos: Producto? = null,
    val mensaje: String? = null
)
